from flask import Flask, request, render_template, redirect
app = Flask(__name__)
from python import information


@app.route('/')
def index():
    return render_template("base.html")


@app.route("/information_call")
def information_call():
    result = information.getInformation()
    return render_template("information.html", object_list=result)


@app.route("/informationAct", methods=["GET", "POST", "PUT", "DELETE"])
def informationAct():
    if request.method == 'GET':
        return information.getInformation()
    elif request.method == 'POST':
        name = request.form['name1']
        sex = request.form['sex1']
        age = request.form['age1']
        addr = request.form['addr1']
        infoData = (name, sex, age, addr)
        return information.setInformation(infoData)

    elif request.method == 'DELETE':
        name = request.form['id']
        return information.delInformation(name)

    elif request.method == 'PUT':
        infoData = request.form
        return information.putInformation(infoData)


if __name__ == '__main__':
    app.run()
