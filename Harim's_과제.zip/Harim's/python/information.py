import json
import pymysql

def getConnection():
    return pymysql.connect(host='192.168.1.243', port = 3306, user = 'root',
                           password = 'big2019', use_unicode=True, db="harimee",
                           charset='utf8', autocommit=True)

def getInformation():
    conn = getConnection()
    cur = conn.cursor()
    cur.callproc("info_select")
    if(cur.rowcount):
        result = cur.fetchall()
        print(result)
    else:
        result = 0;
    cur.close()
    conn.close()
    return result

def setInformation(infoData):
    conn = getConnection()
    cur = conn.cursor()
    # args = (infoData['name'], infoData['sex'], infoData['age'], infoData['addr'], 0)
    cur.callproc("info_insert", infoData)
    result = cur.rowcount
    cur.close()
    conn.close()
    return json.dumps({'rows':result})

def delInformation(in_name):
    conn = getConnection()
    cur = conn.cursor()
    args = (in_name, 0)
    cur.callproc("info_delete", args)
    cur.execute('SELECT @_info_delete_1')
    result = cur.fetchone()
    result = cur.rowcount
    cur.close()
    conn.close()
    return json.dumps({'rows': result})

def putInformation(infoData):
    conn = getConnection()
    cur = conn.cursor()
    args = (infoData["id5"], infoData["name1"], infoData["sex1"], infoData["age1"], infoData["addr1"], 0)
    cur.callproc("info_update", args)
    cur.execute('SELECT @_info_update_5')
    result = cur.fetchone()
    result = cur.rowcount
    cur.close()
    conn.close()
    return json.dumps({'rows': result})
