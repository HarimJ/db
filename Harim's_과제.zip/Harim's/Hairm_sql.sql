-- --------------------------------------------------------
-- 호스트:                          192.168.1.243
-- 서버 버전:                        5.5.64-MariaDB - MariaDB Server
-- 서버 OS:                        Linux
-- HeidiSQL 버전:                  10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- harimee 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `harimee` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `harimee`;

-- 테이블 harimee.information 구조 내보내기
CREATE TABLE IF NOT EXISTS `information` (
  `name` varchar(50) NOT NULL,
  `sex` char(1) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `addr` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 harimee.information:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `information` DISABLE KEYS */;
INSERT INTO `information` (`name`, `sex`, `age`, `addr`) VALUES
	('민범', 'M', 27, '제주도'),
	('서윤', 'W', 27, '서울'),
	('진욱', 'M', 27, '서귀포'),
	('하림', 'W', 26, '제주도');
/*!40000 ALTER TABLE `information` ENABLE KEYS */;

-- 프로시저 harimee.info_delete 구조 내보내기
DELIMITER //
CREATE PROCEDURE `info_delete`(
	IN `in_name` VARCHAR(50),
	OUT `out_res` VARCHAR(50)
)
BEGIN
	DECLARE cnt INT DEFAULT 0;
	SELECT COUNT(*) INTO cnt FROM information WHERE NAME = in_name;
	
	if cnt > 0 then DELETE FROM information WHERE NAME = in_name;
		SET out_res = 0;
	ELSE SET out_res := 2;
	
	END if;
END//
DELIMITER ;

-- 프로시저 harimee.info_insert 구조 내보내기
DELIMITER //
CREATE PROCEDURE `info_insert`(
	IN `in_name` VARCHAR(50),
	IN `in_sex` CHAR(1),
	IN `in_age` INT,
	IN `in_addr` VARCHAR(50)
)
BEGIN
	INSERT INTO information(NAME, sex, age, addr)
	VALUES(in_name, in_sex, in_age, in_addr);
END//
DELIMITER ;

-- 프로시저 harimee.info_select 구조 내보내기
DELIMITER //
CREATE PROCEDURE `info_select`()
BEGIN
	SELECT * FROM information;
END//
DELIMITER ;

-- 프로시저 harimee.info_update 구조 내보내기
DELIMITER //
CREATE PROCEDURE `info_update`(
	IN `searchname` VARCHAR(50),
	IN `updatename` VARCHAR(50),
	OUT `res` VARCHAR(50)
)
BEGIN
	DECLARE cnt INT DEFAULT 0;
	SELECT COUNT(*) INTO cnt FROM information WHERE NAME = searchname;
	if cnt > 0 then UPDATE information SET NAME = updatename WHERE NAME = searchname;
		SET res = 0;
	ELSE SET res = 2;
	END if;
END//
DELIMITER ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
